#ifndef FILE_C
#define FILE_C


#define C_MESSAGE "C\n"

#endif
