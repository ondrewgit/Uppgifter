#ifndef FILE_MAIN
#define FILE_MAIN

#define RETVALUE 0

void print_A();
void print_B();
void print_C();
void print_D();

#endif
